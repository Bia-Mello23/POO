import 'circulo.dart';

void main() {
  Circulo c1 = Circulo(5.0, "vermelho");
  Circulo c2 = Circulo(3.0, "azul");
  Circulo c3 = Circulo(7.5, "verde");

  print("Raio do C1: ${c1.raio}");
  print("Cor do C1: ${c1.cor}");

  print("Resumo C1");
  c1.exibirResumo();

  print("Resumo C2");
  c2.exibirResumo();

  print("Resumo C3");
  c3.exibirResumo();
}