class Circulo {
  
  double _raio;      
  String _cor;       
  static const double PI = 3.14; 

  Circulo(this._raio, this._cor) {
    if (_raio <= 0) {
      throw ArgumentError("O raio deve ser maior que 0!");
    }
    if (_cor.isEmpty) {
      throw ArgumentError("A cor nao pode ser vazia!");
    }
  }

  double get raio => _raio;
  String get cor => _cor;

  double calcularArea() {
    return PI * _raio * _raio;
  }

  double calcularPerimetro() {
    return 2 * PI * _raio;
  }

  void exibirResumo() {
    print("Raio: $_raio");
    print("Cor: $_cor");
    print("Área: ${calcularArea()}");
    print("Perímetro: ${calcularPerimetro()}");
  }
}